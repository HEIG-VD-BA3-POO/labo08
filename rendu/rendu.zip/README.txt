Laboratoire 8: Chess
--------------------

Le rendu content deux dossiers:

- chess_original: code SANS modifications au package chess fourni
- chess_modifier: code AVEC modifications au package chess fourni
