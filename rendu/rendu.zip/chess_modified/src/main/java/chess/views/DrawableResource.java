package chess.views;

public interface DrawableResource<Resource> {
  Resource getResource();
}
